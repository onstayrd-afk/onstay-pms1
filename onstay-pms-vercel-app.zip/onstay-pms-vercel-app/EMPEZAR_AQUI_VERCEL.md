# Proyecto REAL Onstay PMS en Vercel (Flask + Python)

Esta carpeta **es el sistema completo** (mismo codigo que `onstay-pms`): login, panel, reservas, liquidaciones, facturas, PDF, logos, etc.

No uses `onstay-pms-vercel-flat` ni la web estatica con solo HTML: eso es solo demo visual.

---

## 1. Subir a GitHub

1. Crea un repositorio nuevo en GitHub (vacío).
2. Copia **todo el contenido de esta carpeta** `onstay-pms-vercel-app` como **raíz** del repo.
3. Debe quedar en la raíz del repo:
   - `app.py`
   - `requirements.txt`
   - `vercel.json`
   - carpeta `api/` con `index.py`
   - carpetas `static/`, `templates/`, etc.

Comandos ejemplo (PowerShell, dentro de esta carpeta):

```powershell
git init
git add .
git commit -m "Onstay PMS para Vercel"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

El archivo `onstay.db` **no** debe subirse si ya esta en `.gitignore` (`*.db`). En Vercel la base se crea sola en `/tmp` al arrancar.

---

## 2. Conectar Vercel

1. Entra en [vercel.com](https://vercel.com) → **Add New** → **Project**.
2. **Import** tu repositorio de GitHub.
3. **Root Directory**: dejalo en `.` (raíz), donde esta `vercel.json`.
4. **Framework Preset**: Other / detecta Python, o deja automatico.
5. **Environment Variables** → agrega:
   - **Nombre:** `ONSTAY_SECRET`  
   - **Valor:** una frase larga y aleatoria (obligatorio para sesiones seguras).
6. **Deploy**.

Cuando termine, abre la URL que te da Vercel: deberias ver la pantalla de **login** como en tu PC (`http://127.0.0.1:5000`).

---

## 3. Usuarios iniciales

Revisa el `README.md` del proyecto (admin, secretaria, contadora y contraseñas por defecto).

---

## 4. Limitaciones en Vercel (importante)

| Tema | Detalle |
|------|--------|
| SQLite | Se guarda en `/tmp` del servidor. Puede **perderse** entre despliegues o reinicios. |
| Uso recomendado | Pruebas, demo, acceso rapido. |
| Produccion seria | **VPS** (Ubuntu + Gunicorn + Nginx) o base **PostgreSQL** en la nube. |

---

## 5. Si ves error NOT_FOUND (404)

- Confirma que en la raíz del repo existen `vercel.json` y `api/index.py`.
- En Vercel, **Root Directory** apunta a esa raíz (no a una subcarpeta vacia).
- Vuelve a hacer **Redeploy** tras subir los archivos.

---

## 6. Ubicacion en tu PC

`C:\Users\VICTUS\onstay-pms-vercel-app`

(Si tienes copia en el Escritorio, sincroniza los mismos archivos.)
