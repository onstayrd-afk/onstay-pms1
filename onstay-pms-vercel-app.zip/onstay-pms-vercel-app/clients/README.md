# Clientes OnstayRd (escritorio + móvil)

## 3 — Escritorio (.exe)

Carpeta **`desktop-electron/`**

1. Instala [Node.js](https://nodejs.org/).
2. Terminal:
   ```bash
   cd clients/desktop-electron
   npm install
   npm start
   ```
3. Para generar **.exe** en Windows:
   ```bash
   npm run build:win
   ```
4. Pon tu URL en **`onstay-config.json`** (copia del `.example`) junto al programa, o usa variable `ONSTAY_URL`.

Guía detallada: `desktop-electron/README.md`.

---

## 4 — Móvil (Play Store / App Store)

Carpeta **`mobile-capacitor/`**

1. Pon tu URL en **`capacitor.config.json`** (`server.url`).
2. Instala [Node.js](https://nodejs.org/) y **Android Studio** (y Xcode en Mac para iOS).
3. Terminal:
   ```bash
   cd clients/mobile-capacitor
   npm install
   npx cap add android
   npx cap add ios
   npx cap sync
   npx cap open android
   ```

Guía: `mobile-capacitor/README.md`.

---

**Importante:** ambas opciones abren tu **mismo sistema web**; hace falta tenerlo **en un servidor con link público** (no solo `127.0.0.1`).
