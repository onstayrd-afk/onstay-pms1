# OnstayRd PMS — App móvil (Capacitor)

Envuelve tu **misma web** en una app **Android** e **iOS**.

## Antes de nada

1. Publica el panel en internet con **https://** (ver `COMO_PUBLICAR_EN_INTERNET.md` en la raíz del proyecto).
2. Edita **`capacitor.config.json`** → `server.url` con tu dominio real.

## Pasos (resumen)

```bash
cd clients/mobile-capacitor
npm install
npx cap add android
npx cap add ios
npx cap sync
npx cap open android
```

(iOS solo en **Mac** con Xcode.)

En Android Studio: Run en teléfono o emulador. Para Play Store: **Build → Signed App Bundle**.

## Tiendas

- **Google Play:** cuenta de desarrollador (pago único).
- **App Store:** cuenta Apple Developer (anual) + Mac para compilar.

## Nota

Si la última vez algo falló al crear archivos, esta carpeta ya incluye `capacitor.config.json` y `www/`.
