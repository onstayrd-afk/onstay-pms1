/* Preload vacío reservado para futuras APIs seguras */
const { contextBridge } = require("electron");
contextBridge.exposeInMainWorld("onstay", { version: "1.0.0" });
