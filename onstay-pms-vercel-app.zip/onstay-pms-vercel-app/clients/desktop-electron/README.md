# OnstayRd PMS — Escritorio (Electron)

Ventana de **Windows / Mac / Linux** que abre tu mismo panel web (local o publicado en internet).

## Requisitos

- [Node.js](https://nodejs.org/) 18 o superior (incluye `npm`)

## Probar en tu PC (sin compilar .exe)

1. Abre terminal en esta carpeta `desktop-electron`.
2. `npm install`
3. Opcional: copia `onstay-config.example.json` → `onstay-config.json` y pon tu URL real.
4. `npm start`

Si no creas `onstay-config.json`, usa por defecto `http://127.0.0.1:5000` (tienes que tener `python app.py` en marcha).

## Generar .exe para Windows

En la misma carpeta:

```bash
npm install
npm run build:win
```

Los instaladores salen en `dist/`:

- **Instalador** tipo setup (NSIS)
- **Portable** `.exe` (no instala, solo copia)

## Configurar la URL para tu equipo

**Opción A — Archivo** (recomendado para repartir el portable):

1. Junto al `.exe` portable (o en la carpeta del programa instalado), crea **`onstay-config.json`**:

```json
{
  "url": "https://tu-dominio-real.com"
}
```

2. Vuelve a abrir OnstayRd PMS.

**Opción B — Variable de entorno** (al arrancar):

```powershell
$env:ONSTAY_URL="https://tu-dominio.com"; npm start
```

## Icono propio (opcional)

Coloca `assets/icon.ico` (Windows) antes de `npm run build:win`.  
Si no existe, Electron usa el icono por defecto (puedes añadir el logo después).

## Seguridad

- Solo quien tenga **usuario y contraseña** del panel puede usar el sistema (igual que en el navegador).
- Usa **https://** en producción.
