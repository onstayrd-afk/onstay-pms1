/**
 * OnstayRd PMS - Electron
 * Carga tu panel web (local o en internet). Configura la URL abajo o con onstay-config.json
 */
const { app, BrowserWindow, shell } = require("electron");
const path = require("path");
const fs = require("fs");

function loadConfigUrl() {
  if (process.env.ONSTAY_URL && process.env.ONSTAY_URL.trim()) {
    return process.env.ONSTAY_URL.trim();
  }
  const candidates = [
    path.join(__dirname, "onstay-config.json"),
    path.join(path.dirname(process.execPath), "onstay-config.json"),
  ];
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) {
        const j = JSON.parse(fs.readFileSync(p, "utf8"));
        if (j.url && String(j.url).trim()) return String(j.url).trim();
      }
    } catch (_) {
      /* ignore */
    }
  }
  return "http://127.0.0.1:5000";
}

const START_URL = loadConfigUrl();

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 900,
    minHeight: 600,
    title: "OnstayRd PMS",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    show: false,
  });

  win.once("ready-to-show", () => win.show());
  win.loadURL(START_URL);

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
