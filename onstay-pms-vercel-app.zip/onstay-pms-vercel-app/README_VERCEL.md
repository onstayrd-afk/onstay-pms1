# Onstay PMS en Vercel (misma app que en tu PC)

Esta carpeta es el **Onstay PMS completo** (Flask): login, panel, reservas, liquidaciones, facturas, PDF, etc.

La carpeta `onstay-pms-vercel-static` (solo `index.html` + CSS) **no** es el sistema; es solo una página de prueba.

## 1) Qué subir a GitHub

- Crea un repositorio **vacío** o usa uno dedicado.
- Sube **solo el contenido de esta carpeta** `onstay-pms-vercel-app` en la **raíz** del repo (donde están `app.py`, `vercel.json`, `api/`).

## 2) Vercel

1. **Add New Project** → Importa ese repositorio.
2. **Root Directory**: déjalo en `.` (raíz), **no** en una subcarpeta vacía.
3. **Framework Preset**: Other, o detecta Python automáticamente.
4. **Environment Variables**:
   - `ONSTAY_SECRET` = cadena larga y aleatoria (obligatorio para sesiones).
5. Deploy.

Tras el deploy, abre la URL que te da Vercel: deberías ver la **pantalla de login** como en local (`http://127.0.0.1:5000`).

## 3) Usuarios iniciales

Ver `README.md` (admin, secretaria, contadora).

## 4) Limitaciones en Vercel

- La base **SQLite** vive en `/tmp` en el servidor: puede **resetearse** entre despliegues o instancias. Úsalo como demo o pruebas.
- Para producción 24/7 con datos estables: **VPS** o migrar a **PostgreSQL**.

## 5) Si ves 404 NOT_FOUND

- Confirma que el repo tiene `vercel.json` y `api/index.py` en la raíz del proyecto importado.
- Re-deploy después de subir archivos.
